<li>
    <a class="text-white waves-effect" href="{{route('blog.index')}}"><i class="text-white menu-icon bi bi-bootstrap "></i><span>Blog</span></a>
</li>
<li>
    <a class="text-white waves-effect" href="{{route('education.index')}}"><i class="text-white menu-icon bi bi-book-half "></i><span>Education</span></a>
</li>
