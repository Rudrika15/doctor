
<li>
    <a class="text-white waves-effect" href="{{route('doctor.index')}}"><i class="text-white menu-icon bi bi-person-circle "></i><span>Doctor</span></a>
</li>
<li>
    <a class="text-white waves-effect" href="{{route('gallery.index')}}"><i class="text-white menu-icon bi bi-hospital-fill"></i><span>Gallery</span></a>
</li>
<li>
    <a class="text-white waves-effect" href="{{route('facility.index')}}"><i class="text-white menu-icon bi bi-images"></i><span>Facility</span></a>
</li>
<li>
    <a class="text-white waves-effect" href="{{route('schedule.index')}}"><i class="text-white menu-icon bi bi-calendar-day-fill"></i><span>Schedule</span></a>
</li>
<li>
    <a class="text-white waves-effect" href="{{route('appointment.index')}}"><i class="text-white menu-icon bi bi-calendar-day-fill"></i><span>Appointments</span></a>
</li>